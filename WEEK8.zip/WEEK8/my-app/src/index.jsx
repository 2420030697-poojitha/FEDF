import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./App.css";

createRoot(document.getElementById("root")).render(<App />);
[
  { "id": 1, "title": "Learn React Hooks", "completed": false },
  { "id": 2, "title": "Build To-Do App", "completed": false }
]