import React, { useState, useEffect } from "react";

function App() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");

  // Load tasks from localStorage on start
  useEffect(() => {
    const stored = localStorage.getItem("tasks");
    if (stored) setTasks(JSON.parse(stored));
  }, []);

  // Save tasks to localStorage whenever tasks change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;

    setTasks([
      ...tasks,
      { id: Date.now(), title: newTask.trim(), completed: false },
    ]);
    setNewTask("");
  };

  const toggleTask = (id) => {
    setTasks(
      tasks.map((t) =>
        t.id === id ? { ...t, completed: !t.completed } : t
      )
    );
  };

  const updateTask = (id, title) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, title } : t)));
  };

  const deleteTask = (id) => setTasks(tasks.filter((t) => t.id !== id));
  const clearAll = () => { setTasks([]); localStorage.removeItem("tasks"); };

  return (
    <div className="app">
      <h1>📝 To-Do List</h1>
      <form onSubmit={addTask}>
        <input
          type="text"
          placeholder="Enter task"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button type="submit">Add</button>
      </form>

      {tasks.length === 0 ? (
        <p>No tasks. Add one!</p>
      ) : (
        <>
          <ul>
            {tasks.map((task) => (
              <li key={task.id} className={task.completed ? "completed" : ""}>
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task.id)}
                />
                <input
                  type="text"
                  value={task.title}
                  onChange={(e) => updateTask(task.id, e.target.value)}
                />
                <button onClick={() => deleteTask(task.id)}>🗑️</button>
              </li>
            ))}
          </ul>
          <button className="clear" onClick={clearAll}>Clear All</button>
        </>
      )}
    </div>
  );
}

export default App;